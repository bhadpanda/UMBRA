VERSION = '4.7.1'


def version() -> str:
    return VERSION
